<template>
    <div>
        <h1>About Me Page</h1>
      <p>This page belongs to GCS220562 and has been added to the system working on my
         own to demonstrate my ability to add a new item to the menu bar with a new 
         icon of my choice attaching a template from a new view.</p>
    </div>
  </template>